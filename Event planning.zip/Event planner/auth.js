// Initialize unified app data structure
if (!localStorage.getItem('appData')) {
  localStorage.setItem('appData', JSON.stringify({
    users: [
      {
        id: 1,
        name: 'Rose',
        email: 'rose@admin.com',
        password: 'itsmeagain',
        role: 'admin',
        bookings: []
      }
    ],
    events: [],
    bookings: []
  }));
}

// Helper functions
const getAppData = () => JSON.parse(localStorage.getItem('appData'));
const saveAppData = (data) => localStorage.setItem('appData', JSON.stringify(data));

// Login Handler
document.getElementById('loginForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value.trim().toLowerCase();
  const password = document.getElementById('loginPassword').value.trim();
  const appData = getAppData();

  const user = appData.users.find(u => 
    u.email.toLowerCase() === email && 
    u.password === password
  );

  if (user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
    switch(user.role.toLowerCase()) {
      case 'admin':
        window.location.href = 'admin-dashboard.html';
        break;
      case 'planner':
        window.location.href = 'planner-dashboard.html';
        break;
      default:
        window.location.href = 'user-dashboard.html';
    }
  } else {
    alert('Invalid credentials');
    document.getElementById('loginPassword').value = '';
  }
});

// Signup Handler
document.getElementById('signupForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  const name = document.getElementById('signupName').value.trim();
  const email = document.getElementById('signupEmail').value.trim().toLowerCase();
  const password = document.getElementById('signupPassword').value.trim();

  const appData = getAppData();
  
  if (appData.users.some(u => u.email.toLowerCase() === email)) {
    alert('Email already exists!');
    return;
  }

  const newUser = {
    id: Date.now(),
    name,
    email,
    password,
    role: 'user',
    bookings: []
  };

  appData.users.push(newUser);
  saveAppData(appData);
  
  alert('Account created successfully! Please login.');
  window.location.href = 'login.html';
});