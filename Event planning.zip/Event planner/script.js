document.addEventListener('DOMContentLoaded', function() {
  console.log('Script loaded and running');
  
  // Location Preview System
  const locationSelect = document.getElementById('event-location');
  const locationInfo = document.getElementById('location-info');
  const locationImage = document.getElementById('location-image');
  const viewMapLink = document.getElementById('view-map');
  
  if (!locationSelect) {
    console.error('Location select element not found');
  }
  
  if (!locationInfo) {
    console.error('Location info element not found');
  }
  
  if (!locationImage) {
    console.error('Location image element not found');
  }
  
  if (!viewMapLink) {
    console.error('View map link element not found');
  }
  
  if (locationSelect) {
    console.log('Adding change event to location select');
    
    locationSelect.addEventListener('change', function() {
      console.log('Location changed to:', this.value);
      
      if (this.value) {
        const selectedOption = this.options[this.selectedIndex];
        const coords = selectedOption.getAttribute('data-coords');
        console.log('Coordinates:', coords);
        
        // Try multiple image approaches
        const imagePath = `assets/${this.value.toLowerCase()}.png`;
        console.log('Trying to load image from:', imagePath);
        
        // Set the image source
        locationImage.src = imagePath;
        locationImage.alt = `${this.value} location`;
        
        // Ensure image is visible
        locationImage.style.display = 'block';
        
        // Debug image loading
        locationImage.onload = function() {
          console.log('Image loaded successfully');
        };
        
        locationImage.onerror = function() {
          console.error('Image failed to load, trying fallback');
          // Fallback to Unsplash
          locationImage.src = `https://source.unsplash.com/600x400/?${this.value},city`;
        };
        
        // Set up map link (using both formats to ensure one works)
        if (coords) {
          const googleMapsUrl = `https://www.google.com/maps?q=${coords}`;
          console.log('Setting map link to:', googleMapsUrl);
          viewMapLink.href = googleMapsUrl;
          
          // Remove any event listeners from the map link
          viewMapLink.onclick = null;
          
          // Ensure it opens in a new tab
          viewMapLink.setAttribute('target', '_blank');
          viewMapLink.setAttribute('rel', 'noopener noreferrer');
        }
        
        // Make sure the location info is visible
        locationInfo.classList.remove('hidden');
        locationInfo.style.display = 'block';
      } else {
        locationInfo.classList.add('hidden');
      }
    });
  }
  
  // Direct handling for map link
  if (viewMapLink) {
    console.log('Setting up map link direct handler');
    
    // Replace any existing click handler with a simple one
    viewMapLink.onclick = function(e) {
      console.log('Map link clicked, navigating to:', this.href);
      // Don't prevent default, let the browser handle it
      return true;
    };
  }
});