// Admin Dashboard Functions
const adminCredentials = {
  username: "rose",
  password: "itsmeagain"
};
document.addEventListener('DOMContentLoaded', () => {
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));
  if (!currentUser) window.location.href = 'login.html';

  // Load Users
  if (document.getElementById('userList')) {
    const users = JSON.parse(localStorage.getItem('users'));
    const userList = document.getElementById('userList');
    
    users.forEach(user => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${user.name}</td>
        <td>${user.email}</td>
        <td>${user.AssignTeam}</td>
        <td>
          <select class="AssignTeam-select" data-id="${user.id}">
            <option ${user.AssignTeam === 'Lion' ? 'selected' : ''}>Lion</option>
            <option ${user.AssignTeam === 'planner' ? 'selected' : ''}>planner</option>
            ${currentUser.AssignTeam === 'super-admin' ? 
              `<option ${user.AssignTeam === 'Cheetah' ? 'selected' : ''}>Cheetah</option>` : ''}
          </select>
          <button class="delete-user" data-id="${user.id}">Delete</button>
        </td>
      `;
      userList.appendChild(row);
    });
  }
});

// AssignTeam Update Handler
document.addEventListener('change', (e) => {
  if (e.target.classList.contains('AssignTeam-select')) {
    const users = JSON.parse(localStorage.getItem('users'));
    const user = users.find(u => u.id == e.target.dataset.id);
    user.AssignTeam = e.target.value;
    localStorage.setItem('users', JSON.stringify(users));
  }
});

// Delete User Handler
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('delete-user')) {
    const users = JSON.parse(localStorage.getItem('users'))
      .filter(u => u.id != e.target.dataset.id);
    localStorage.setItem('users', JSON.stringify(users));
    e.target.closest('tr').remove();
  }
});