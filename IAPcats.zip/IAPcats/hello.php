<?php
echo("hello, world!");// displays output
?>
