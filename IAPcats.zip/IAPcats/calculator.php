<?php
echo"<h2>PHP CALCULATOR.</h2>";
$a = 10;
$b = 20;

// Addition
echo"<h2>ADDITION.</h2>";
$addition = $a + $b;
echo "<h3>Addition of $a and $b is: $addition</h3> ";

// Subtraction
echo"<h2>SUBTRACTION.</h2>";
$subtraction = $b - $a;
echo "<h3>Subtraction of $a from $b is: $subtraction</h3>";

// Multiplication
echo"<h2>MULTIPLICATION.</h2>";
$multiplication = $a * $b;
echo "<h3>Multiplication of $a and $b is: $multiplication</h3>";

// Division
echo"<h2>DIVISION.</h2>";
if ($a != 0) {
    $division = $b / $a;
    echo "<h3>Division of $b by $a is: $division</h3>";
} else {
    echo "<h3>Division by zero error</h3>";
}

// Modulus
$modulus = $b % $a;
echo"<h2>MODULUS.</h2>";
echo "<h3>Modulus of $b by $a is: $modulus</h3>";
?>
